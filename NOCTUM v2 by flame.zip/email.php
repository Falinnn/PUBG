<?php
$emailku = 'kprastiko12@gmail.com'; // GANTI EMAIL KAMU DISINI
?>